/*
 * MPU6050.h
 *
 *  Created on: May 24, 2022
 *      Author: Villiam Bo
 *      Code is inspired by T.Jaber's MPU6050 6 axis module from 25 Mar 2019.
 */

#ifndef SRC_MPU6050_H_
#define SRC_MPU6050_H_

#define MPU_ADDR			0x68
#define PWR_MAGT_1_REG		0x6B
#define CONFIG_REG			0x1A
#define GYRO_CONFIG_REG		0x1B
#define ACCEL_CONFIG_REG	0x1C
#define INT_STATUS_REG		0x3A
#define ACCEL_XOUT_H_REG	0x3B
#define TEMP_OUT_H_REG		0x41
#define GYRO_XOUT_H_REG		0x43

#include "stm32l4xx_hal.h"  //dpending on your board
#include <string.h>
#include <stdbool.h>	//Boolean
#include <math.h>			//Pow()

//TypeDefs and Enums
//1- MPU Configuration
typedef struct
{
	uint8_t ClockSource;
	uint8_t Gyro_Full_Scale;
	uint8_t Accel_Full_Scale;
	uint8_t CONFIG_DLPF;
	bool 	Sleep_Mode_Bit;

}MPU_ConfigTypeDef;

//7. Raw data typedef
typedef struct
{
	int16_t x;
	int16_t y;
	int16_t z;
}RawData_Def;

//8. Scaled data typedef
typedef struct
{
	float x;
	float y;
	float z;
}ScaledData_Def;

//4- Accelerometer Full Scale Range ENUM (1g = 9.81m/s2)
enum accel_FullScale
{
	AFS_SEL_2g	= 0x00,
	AFS_SEL_4g 	= 0x01,
	AFS_SEL_8g	= 0x02,
	AFS_SEL_16g = 0x03
};

//5- Digital Low Pass Filter ENUM
enum DLPF_CFG
{
	DLPF_260A_256G_Hz 	= 0x00,
	DLPF_184A_188G_Hz 	= 0x01,
	DLPF_94A_98G_Hz 	= 0x02,
	DLPF_44A_42G_Hz 	= 0x03,
	DLPF_21A_20G_Hz 	= 0x04,
	DLPF_10_Hz 			= 0x05,
	DLPF_5_Hz 			= 0x06
};

enum PM_CLKSEL
{
	Internal_8MHz 		= 0x00,
	X_Axis_Ref			= 0x01,
	Y_Axis_Ref			= 0x02,
	Z_Axis_Ref			= 0x03,
	Ext_32_768KHz		= 0x04,
	Ext_19_2MHz			= 0x05,
	TIM_GENT_INREST		= 0x07
};

//3- Gyro Full Scale Range ENUM (deg/sec)
enum Gyro_FullScale
{
	FS_SEL_250 	= 0x00,
	FS_SEL_500 	= 0x01,
	FS_SEL_1000 = 0x02,
	FS_SEL_2000	= 0x03
};

void I2C_Read(uint8_t ADDR, uint8_t *i2cBuf, uint8_t NofData);
void I2C_Write(uint8_t ADDR, uint8_t data);
void MPU6050_Init_Config(I2C_HandleTypeDef *I2Chnd, MPU_ConfigTypeDef *config);
void MPU6050_Scale_Data(ScaledData_Def *scaledDefGyro, ScaledData_Def *scaledDefAccel, RawData_Def *rawDefGyro, RawData_Def *rawDefAccel);
void MPU6050_Get_RawData(RawData_Def *rawDefGyro, RawData_Def *rawDefAccel);
#endif /* SRC_MPU6050_H_ */
