/*
 * controller.h
 *
 *  Created on: May 19, 2022
 *      Author: Villiam Bo
 */

#ifndef SRC_CONTROLLER_H_
#define SRC_CONTROLLER_H_

#include <stdint.h>

struct ControllerData
{
	float Ts; //sample time
	int16_t setPoint;
	int16_t currentValue;
	int16_t oldError;
	float Kp;
	float Ti;
	float Td;
	int16_t oldDif;
	int16_t iMax;
	int16_t iMin;
	int16_t oldIntegral;
	int16_t out;

};


void controlSpeed(struct ControllerData*);

void initControllerdata(struct ControllerData*);

#endif /* SRC_CONTROLLER_H_ */
