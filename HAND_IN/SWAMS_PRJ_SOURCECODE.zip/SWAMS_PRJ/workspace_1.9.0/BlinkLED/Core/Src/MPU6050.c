/*
 * MPU6050.c
 *
 *  Created on: May 24, 2022
 *      Author: Villiam Bo
 *      Code is inspired by T.Jaber's MPU6050 6 axis module from 25 Mar 2019.
 */

#include "MPU6050.h"

static I2C_HandleTypeDef i2cHandler;

static float accelScalingFactor, gyroScalingFactor;


void I2C_Read(uint8_t ADDR, uint8_t *i2cBif, uint8_t NofData)
{
	uint8_t i2cBuf[2];
	uint8_t MPUADDR;
	MPUADDR = (MPU_ADDR<<1);
	i2cBuf[0] = ADDR;
	HAL_I2C_Master_Transmit(&i2cHandler, MPUADDR, i2cBuf, 1, 10);
	HAL_I2C_Master_Receive(&i2cHandler, MPUADDR, i2cBif, NofData, 100);
}

void I2C_Write(uint8_t ADDR, uint8_t data)
{
	uint8_t i2cData[2];
	i2cData[0] = ADDR;
	i2cData[1] = data;
	uint8_t MPUADDR = (MPU_ADDR<<1);
	HAL_I2C_Master_Transmit(&i2cHandler, MPUADDR, i2cData, 2,100);
}

void MPU6050_Init_Config(I2C_HandleTypeDef *I2Chnd, MPU_ConfigTypeDef *config)
{
	memcpy(&i2cHandler, I2Chnd, sizeof(*I2Chnd)); //save reference to I2C object in local variable

	HAL_Delay(140); //wait until everything is booted.

	uint8_t Buffer = 0;

	I2C_Write(PWR_MAGT_1_REG, 0x80); //Reset MPU6050
	HAL_Delay(100); //Reset time limit

	Buffer = config ->ClockSource & 0x07; //Change the CLKSEL (first three bits)
	Buffer |= (config ->Sleep_Mode_Bit << 6) &0x40; //Set SLEEP bit (7th bit)
	I2C_Write(PWR_MAGT_1_REG, Buffer); // write to Power Management 1 register
	HAL_Delay(10); //Wait 10 ms for PLL clock change to steady

	//Internal low Pass Filter
	Buffer = 0;
	Buffer = config->CONFIG_DLPF & 0x07; //Set DLPF_CFG bits
	I2C_Write(CONFIG_REG, Buffer); //Writes to the CONFIG register

	//Gyroscope Full Scale Range
	Buffer = 0;
	Buffer = (config->Gyro_Full_Scale << 3) & 0x18; //Set the FS_SEL bits
	I2C_Write(GYRO_CONFIG_REG, Buffer); //Writes to the GYRO_CONFIG register

	//Accelerometer Full Scale Range
	Buffer = 0;
	Buffer = (config->Accel_Full_Scale << 3) & 0x18;  //Set the FS_SEL bits
	I2C_Write(ACCEL_CONFIG_REG, Buffer); //Writes to the ACCEL_CONFIG register


	//Set the actual Accel and Gyro Scaling Factor
	switch (config->Accel_Full_Scale)
	{
		case AFS_SEL_2g:
			accelScalingFactor = (2048.0f/32768.0f);
			break;

		case AFS_SEL_4g:
			accelScalingFactor = (4096.0f/32768.0f);
				break;

		case AFS_SEL_8g:
			accelScalingFactor = (8192.0f/32768.0f);
			break;

		case AFS_SEL_16g:
			accelScalingFactor = (16384.0f/32768.0f);
			break;

		default:
			break;
	}
	//Gyroscope Scaling Factor
	switch (config->Gyro_Full_Scale)
	{
		case FS_SEL_250:
			gyroScalingFactor = 250.0f/32768.0f;
			break;

		case FS_SEL_500:
				gyroScalingFactor = 500.0f/32768.0f;
				break;

		case FS_SEL_1000:
			gyroScalingFactor = 1000.0f/32768.0f;
			break;

		case FS_SEL_2000:
			gyroScalingFactor = 2000.0f/32768.0f;
			break;

		default:
			break;
	}

}

void MPU6050_Get_RawData(RawData_Def *rawDefGyro, RawData_Def *rawDefAccel){
	uint8_t i2cBuf[2];
	uint8_t AcceArr[6], GyroArr[6]; //Holds the 6 bytes of accel and gyro data

	I2C_Read(INT_STATUS_REG, &i2cBuf[1],1);

	if((i2cBuf[1]&&0x01))
	{
		I2C_Read(ACCEL_XOUT_H_REG, AcceArr,6);

		//Accel Raw Data
		rawDefAccel->x = ((AcceArr[0]<<8) + AcceArr[1]);
		rawDefAccel->y = ((AcceArr[2]<<8) + AcceArr[3]);
		rawDefAccel->z = ((AcceArr[4]<<8) + AcceArr[5]);

		//Gyro Raw Data
		I2C_Read(GYRO_XOUT_H_REG, GyroArr,6);
		rawDefGyro->x = ((GyroArr[0]<<8) + GyroArr[1]);
		rawDefGyro->y = (GyroArr[2]<<8) + GyroArr[3];
		rawDefGyro->z = ((GyroArr[4]<<8) + GyroArr[5]);
	}
}

void MPU6050_Scale_Data(ScaledData_Def *scaledDefGyro, ScaledData_Def *scaledDefAccel, RawData_Def *rawDefGyro, RawData_Def *rawDefAccel)
{
	//Gyro Scale data
	scaledDefGyro->x = (rawDefGyro->x)*gyroScalingFactor;
	scaledDefGyro->y = (rawDefGyro->y)*gyroScalingFactor;
	scaledDefGyro->z = (rawDefGyro->z)*gyroScalingFactor;

	//Accel Scale data
	scaledDefAccel->x = (rawDefAccel->x)*accelScalingFactor;
	scaledDefAccel->y = (rawDefAccel->y)*accelScalingFactor;
	scaledDefAccel->z = (rawDefAccel->z)*accelScalingFactor;
}

