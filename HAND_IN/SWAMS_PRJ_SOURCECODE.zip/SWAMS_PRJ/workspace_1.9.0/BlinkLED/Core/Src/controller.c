/*
 * controller.c
 *
 *  Created on: May 19, 2022
 *      Author: Villi
 */

#include "controller.h"
#include <math.h>


void controlSpeed(struct ControllerData* ctrData){

	int16_t err = ctrData->setPoint - ctrData->currentValue;
	int16_t prop =  err;
	int16_t integral = ceil(ctrData->oldIntegral + (ctrData->Ts/2)*(err + ctrData->oldError));

	if(integral > ctrData->iMax){
		integral = ctrData->iMax;
	}
	else if(integral < ctrData->iMin){
		integral = ctrData->iMin;
	}

	int16_t Dif = -1*ctrData->oldDif + (2/ctrData->Ts) * (err - ctrData->oldError);

	ctrData->oldIntegral = integral;
	ctrData->oldDif = Dif;
	ctrData->out = ctrData->Kp*(prop+integral/ctrData->Ti+Dif*ctrData->Td);
	ctrData->oldError = err;

}

void initControllerdata(struct ControllerData* ctrData){
	ctrData->Ti = 100;
	ctrData->Ts = 0.1; //sampling time
	ctrData->Td = 0.00001;
	ctrData->Kp = 5;
	ctrData->iMax = 100;
	ctrData->iMin = -100;
	ctrData->oldIntegral = 0;
	ctrData->setPoint = 0;
	ctrData->currentValue = 0;
	ctrData->oldError = 0;
	ctrData->oldDif = 0;
}




